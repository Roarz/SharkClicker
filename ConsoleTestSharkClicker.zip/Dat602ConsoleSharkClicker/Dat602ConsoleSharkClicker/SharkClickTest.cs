﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Dat602ConsoleSharkClicker // collection of names that belong to our project. Our project's namespace.
{
    class SharkClickerTest
    {
        
        public void ProceduresTest()
        {

            Console.Title = "Console Test Application for SharkClicker";
            Console.WriteLine(@"   _____ _                _        _____ _ _      _             ");
            Console.WriteLine(@"  / ____| |              | |      / ____| (_)    | |            ");
            Console.WriteLine(@" | (___ | |__   __ _ _ __| | __  | |    | |_  ___| | _____ _ __ ");
            Console.WriteLine(@"  \___ \| '_ \ / _` | '__| |/ /  | |    | | |/ __| |/ / _ \ '__|");
            Console.WriteLine(@"  ____) | | | | (_| | |  |   <   | |____| | | (__|   <  __/ |   ");
            Console.WriteLine(@" |_____/|_| |_|\__,_|_|  |_|\_\   \_____|_|_|\___|_|\_\___|_|   ");
            Console.WriteLine();

            using (var SharkClicker = new sharkclickerEntities())
            {

                  /////////////////////////////////////////////////////////////
                 //////////    Testing Player and Game Procedures    /////////
                /////////////////////////////////////////////////////////////
                
                // This method deletes all records from all tables except the player table. The sole purpose of this method is to make the test run smoother.
                SharkClicker.DeleteAllGamesMethod();
                
                //Login players
                SharkClicker.LoginPlayerMethod("Gittyburg", "123456"); // Inserting players into the player table. The login player method will automatically decide whether a player exists or needs to be created.
                SharkClicker.LoginPlayerMethod("Ror", "434343");
                SharkClicker.LoginPlayerMethod("George", "georgies");
                SharkClicker.LoginPlayerMethod("Max", "passy1");
                SharkClicker.LoginPlayerMethod("Smithy", "mypass432");

                //Simulting a player getting locked by entering their password wrong 5 times.
                SharkClicker.LoginPlayerMethod("Smithy", "wrongpassy1");
                SharkClicker.LoginPlayerMethod("Smithy", "wrongpassy1");
                SharkClicker.LoginPlayerMethod("Smithy", "wrongpassy1");
                SharkClicker.LoginPlayerMethod("Smithy", "wrongpassy1");
                SharkClicker.LoginPlayerMethod("Smithy", "wrongpassy1");
                SharkClicker.LoginPlayerMethod("Smithy", "mypass432"); //Still locked. Even though he entered his password correctly this time, the system stops him from logging in.

                //Log off a player
                SharkClicker.LogoffMethod("Max");
                
                // Display players from player table
                ViewPlayers();
                PauseTest();
             
                //Show online list. This method runs a select statement to show the list of available players.
                SharkClicker.ShowOnlineListMethod(); // This method does get called by the login method anyway.

                // Creating a game between two players
                int GameID = 1;
                System.Data.Objects.ObjectParameter GameIDOut = new System.Data.Objects.ObjectParameter("prGameID", GameID);
                SharkClicker.ChallengePlayerMethod("George", "Gittyburg", GameIDOut);
                @GameID = (int)GameIDOut.Value; // Shows the value stored in the out parameter (GameIDOut). This has been put in the game table.
                
                // Displays a list of all the games stored in the games table
                Console.Write("A player has challenged another player to a game of Shark Clicker. A record on \nthe game table has been created: \n\n");
                ViewGames();
                PauseTest();

                // Accepting the game challenge so we can create a board for them to play on
                SharkClicker.AcceptChallengeMethod(@GameID); // this method calls the lay out board method therefore it creates a board.
                
                // Displays a list of all the games stored in the games table
                Console.Write("\nThe challenge has been accepted. A board has been created for the players: \n\n");
                ViewBoards();
                PauseTest();

                // Simulate gameplay of a player clicking sharks (PlayerID, SharkID).
                int HighestSharkID = (from sharks in SharkClicker.sharks select sharks.SharkID).Max(); // creating a variable that uses the highest shark ID in the shark table to determine which shark to click.
                int WinnerID = 1; // ID: 1 = Gittyburg, ID: 3 = George
                SharkClicker.ClickSharkMethod(WinnerID, (HighestSharkID - 3)); // The current shark with the Shark ID that is the highest - 3 will be clicked 
                SharkClicker.ClickSharkMethod(WinnerID, (HighestSharkID)); // The shark with the highest shark ID will be clicked.
                SharkClicker.ClickSharkMethod(3, (HighestSharkID - 3)); // This shark is clicked twice 

                // Displaying the records in the shark table.
                Console.Write("\nClick Shark Method Test:\n\n");
                Console.Write("Below is a list of sharks with their locations on x and y axis. Notice some of \nthem have been clicked so their speed has increased and they have moved to the \ntop of the Y-axis (Where y position = 100): \n\n");
                ViewSharks(); //shows the records in the shark table
                PauseTest();
                Console.WriteLine("Please wait");

                // Testing moving the sharks down the y-axis
                int MovementAmount = 60;
                SharkClicker.MoveSharksTestMethod(MovementAmount);
                Console.WriteLine("\n\n\n\n\nMove Sharks Method Test:");
                Console.WriteLine("\nMovement Amount: " + MovementAmount);
                Console.Write("\nNotice that all sharks have been moved down the y axis. Some of them have hit\nthe bottom of the y-axis which has moves them back to the top of the y-axis and to a random point of the x-axis: \n\n");
                ViewSharks(); // shows the records in the shark table
                PauseTest();

                // Showing the game between the two players and their scores. The player ID for each player is replaced with the correct player name from the player table.
                var PlayerGameList =  from playerGames in SharkClicker.playergames
                                      join players in SharkClicker.players on playerGames.PlayerID equals players.PlayerID
                                      orderby playerGames.Score descending
                                      select new { playerGames.GameID, players.PlayerName, playerGames.Score };

                Console.Write("\nBelow is a list showing the score for each player and the ID of the game they \nare playing in. The score represents how many sharks the player has clicked: \n\n");
                Console.Write("  Game ID\tPlayer name  \tScore \n\n");
                foreach (var group in PlayerGameList)
                {
                    Console.Write("  " + group.GameID + "\t\t"
                    + group.PlayerName + "     \t" + group.Score);
                    Console.WriteLine();
                }
                PauseTest();

                // Writing the winning player in the console
                Console.Write("\n\n");
                var WinningPlayer = (from playerGames in SharkClicker.playergames
                                     join players in SharkClicker.players on playerGames.PlayerID equals players.PlayerID
                                     orderby playerGames.Score descending
                                     select players.PlayerName).First(); // stores the name of the winning player in the WinningPlayer variable

                Console.Write("The Winner of game " + @GameID + " is: \n" + WinningPlayer + "\n");
                PauseTest();

                // End of game
                SharkClicker.GameOverMethod(@GameID);

                // Another use case of a challenge being declined
                SharkClicker.ChallengePlayerMethod("Ror", "Gittyburg", GameIDOut);
                @GameID = (int)GameIDOut.Value; // new game is created. This new GameID is used to decline this new challenge.
                SharkClicker.DeclineChallengeMethod(@GameID); // challenge has been declined. Both players now available again.

                /////////////////////////////////////////////
                //////////    Admin Methods Test    ////////
                ///////////////////////////////////////////

                SharkClicker.ViewPlayersMethod(); // Gives the administrator a list of the players in their system. Shows only important attributes.
                SharkClicker.LoginPlayerMethod("Steve", "Lazypass7"); // Allows the administrator to create a new player record. They follow the same method as a player i.e. can only create a player if player name doesnt already exist. 
                SharkClicker.ViewRunningGamesMethod();
                SharkClicker.DeletePlayerMethod("Ror"); // when a player is deleted, only the player and playergame tables are affected.
                SharkClicker.UnlockPlayerMethod("Smithy"); // Smithy was locked. This method unlocks his account and changes his status to offline
                SharkClicker.ChangePasswordMethod("Smithy", "NewPass1");
                SharkClicker.KillRunningGameMethod(@GameID); // deletes all data that associates with the last game that was created. Can only delete running games from this method.

                // At this point, the player Gittyburg has won a game against george. The administrator has also deleted player ror. We should be able to see these changes. 
                Console.Write("The data in the players table has been updated. Notice the winning streak for \nthe winning player has increased.\n");
                ViewPlayers();
                Console.Write("\n\n");

                Console.ReadLine();

                Console.WriteLine(@"      ,|");
                Console.WriteLine(@"     / ;");
                Console.WriteLine(@"    /  \");
                Console.WriteLine(@"   : ,'(");
                Console.WriteLine(@"   |( `.\");
                Console.WriteLine(@"   : \  `\       \.");
                Console.WriteLine(@"    \ `.         | `.");
                Console.WriteLine(@"     \  `-._     ;   \");
                Console.WriteLine(@"      \     ``-.'.. _ `._");
                Console.WriteLine(@"       `. `-.            ```-...__");
                Console.WriteLine(@"        .'`.        --..          ``-..____");
                Console.WriteLine(@"      ,'.-'`,_-._            ((((   <o.   ,'      Shark Clicker © 2014");
                Console.WriteLine(@"           `' `-.)``-._-...__````  ____.-'");
                Console.WriteLine(@"               ,'    _,'.--,---------'");
                Console.WriteLine(@"           _.-' _..-'   ),'");
                Console.WriteLine(@"          ``--''        `");

            }        
        }

        // Methods used to display records in tables.
        private void ViewSharks() // method displaying records in the shark table.
        {
            var SharkClicker = new sharkclickerEntities();
            Console.Write("  SharkID \tX Position \tY Position \tSpeed\n\n");
            var sharkList = from sharks in SharkClicker.sharks select sharks;
            foreach (var shark in sharkList)
            {
                Console.Write("  " + shark.SharkID + "\t\t"
                    + shark.LocationX + "\t\t" + shark.LocationY + "\t\t" + shark.Speed);
                Console.WriteLine();
            }

        }

        private void ViewPlayers()
        {
            var SharkClicker = new sharkclickerEntities();
            var playerList = from players in SharkClicker.players select players;
            Console.WriteLine();
            Console.Write("List of Players: \n\n");
            Console.Write("  PlayerName\tPassword\tStatus  \tWinningStreak \n\n");
            foreach (var player in playerList)
            {
                Console.Write("  " + player.PlayerName + "   " + "\t"
                    + player.PlayerPassword + "   " + "\t"
                    + player.PlayerStatus + "   " + "\t" + player.WinningStreak);
                Console.WriteLine();
            }
        }

        private void ViewGames()
        {
            var SharkClicker = new sharkclickerEntities();
            var gameList = from games in SharkClicker.games select games;
            Console.Write("  GameID \tTime Started \t\t\tTime Remaining\n\n");
            foreach (var game in gameList)
            {
                Console.Write("  " + game.GameID + "\t\t"
                    + game.TimeStarted + "     \t" + game.TimeRemaining);
                Console.WriteLine();
            }
        }

        private void ViewBoards()
        {
            var SharkClicker = new sharkclickerEntities();
            var boardList = from boards in SharkClicker.boards select boards;
            Console.Write(" BoardID \tMax Width \tMax Height \tMaximum Sharks\n\n");
            foreach (var board in boardList)
            {
                Console.Write("  " + board.BoardID + "\t\t"
                    + board.MaxWidth + "\t\t" + board.MaxHeight + "\t\t" + board.MaximumSharks);
                Console.WriteLine();
            }
        }

        private void PauseTest()
        {
            Console.Write("\nPress the enter key to continue\n\n");
            Console.ReadLine();
        }
    }


}
