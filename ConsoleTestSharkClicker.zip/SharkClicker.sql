DROP DATABASE IF EXISTS SharkClicker;
CREATE DATABASE SharkClicker;
USE SharkClicker;

/*
///////////////////////////////////////////////////////////////
-- ///////    Creating The Database Schema     ///////////////
/////////////////////////////////////////////////////////////
*/

DELIMITER //
CREATE PROCEDURE CreateGameSchema()
BEGIN
	
	CREATE TABLE Player( 
		PlayerID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
		PlayerName VARCHAR(20),
		PlayerPassword VARCHAR(20),
		LastOnline DATETIME DEFAULT CURRENT_TIMESTAMP,
		WinningStreak INTEGER(5) DEFAULT 0,
		TriesLeft INTEGER DEFAULT 5,
		PlayerStatus VARCHAR(20) DEFAULT 'Available'
	);
	
	CREATE TABLE Game( 
		GameID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
		TimeStarted DATETIME DEFAULT CURRENT_TIMESTAMP,
		TimeRemaining INT DEFAULT 120 -- game runs for 120 seconds
	);

	CREATE TABLE Board( 
		BoardID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
		GameID INT NOT NULL,
		MaxWidth INTEGER(5) DEFAULT 100,
		MaxHeight INTEGER(5) DEFAULT 100,
		MaximumSharks INTEGER(3) DEFAULT 5,
		FOREIGN KEY (GameID) REFERENCES Game(GameID) ON DELETE CASCADE
	);

	CREATE TABLE Shark( 
		SharkID INT NOT NULL AUTO_INCREMENT,
		BoardID INT NOT NULL,
		LocationX INTEGER(5) DEFAULT 1,
		LocationY INTEGER(5) DEFAULT 100,
		Speed INTEGER(10) DEFAULT -1,
		FOREIGN KEY (BoardID) REFERENCES Board(BoardID) ON DELETE CASCADE,
		PRIMARY KEY (SharkID, BoardID)
	);

	CREATE TABLE PlayerGame( 
		GameID INT NOT NULL,
		PlayerID INT NOT NULL,
		ChallengeStatus VARCHAR(20) DEFAULT 'Pending',
		Score INTEGER(5) DEFAULT 0,
		FOREIGN KEY (PlayerID) REFERENCES Player(PlayerID) ON DELETE CASCADE,
		FOREIGN KEY (GameID) REFERENCES Game(GameID) ON DELETE CASCADE,
		PRIMARY KEY (PlayerID, GameID)
	);

END//
DELIMITER ;

/*
///////////////////////////////////////////////////////////////
-- ///////     Player and game procedures      ///////////////
/////////////////////////////////////////////////////////////
*/
DELIMITER //
CREATE PROCEDURE LoginPlayer(IN prPlayerName VARCHAR(20), IN prPlayerPassword VARCHAR(20))
BEGIN
	
	SET @PLAYERPASSWORD = (SELECT PlayerPassword FROM Player WHERE PlayerName = prPlayerName);
	SET @PLAYERSTATUS = (SELECT PlayerStatus FROM Player WHERE PlayerName = prPlayerName);

	IF @PLAYERSTATUS = 'Locked' THEN
		SELECT 'You have been locked out. Contact admin@game.com for help.' AS Locked;
	ELSE
		IF PlayerExists(prPlayerName) = TRUE AND @PLAYERPASSWORD = prPlayerPassword THEN
			UPDATE Player
			SET PlayerStatus = 'Available', TriesLeft = default
			WHERE PlayerName = prPlayerName;
			SELECT CONCAT('Welcome back ', prPlayerName) AS WelcomeBack;
			CALL ShowOnlineList();
		ELSEIF PlayerExists(prPlayerName) = TRUE AND NOT @PLAYERPASSWORD = prPlayerPassword THEN
			UPDATE Player
			SET TriesLeft = TriesLeft - 1
			WHERE PlayerName = prPlayerName;
			CALL LockPlayer();
			SELECT 'Password entered is incorrect.' AS Warning, TriesLeft FROM Player WHERE PlayerName = prPlayerName;
		ELSE 
			CALL CreatePlayer(prPlayerName, prPlayerPassword);
			SELECT CONCAT('Welcome ', prPlayerName,'. You are about to start as a new player.') AS NewPlayer;
			CALL ShowOnlineList();
		END IF;
	END IF;
END//
DELIMITER ;

-- CREATE A PLAYER RECORD
DELIMITER //
CREATE PROCEDURE CreatePlayer(IN prPlayerName VARCHAR(20), IN prPlayerPassword VARCHAR(20))
BEGIN
	INSERT INTO Player(PlayerName, PlayerPassword) VALUES (prPlayerName, prPlayerPassword);
END//
DELIMITER ;

-- DISPLAY PLAYERS ONLINE LIST.
DELIMITER //
CREATE PROCEDURE ShowOnlineList()
BEGIN
	SELECT PlayerName, PlayerStatus, WinningStreak FROM Player WHERE PlayerStatus = 'Available';
END//
DELIMITER ;

-- lock player.
DELIMITER //
CREATE PROCEDURE LockPlayer()
BEGIN
	UPDATE Player
	SET PlayerStatus = 'Locked'
	WHERE TriesLeft = 0;
END//
DELIMITER ;

-- Log off player.
DELIMITER //
CREATE PROCEDURE Logoff(IN prPlayerName VARCHAR(20))
BEGIN
	UPDATE Player
	SET PlayerStatus = 'Offline', LastOnline = CURRENT_TIMESTAMP
	WHERE PlayerName = prPlayerName;
	SELECT prPlayerName AS LoggingOff;
	CALL ShowOnlineList(); -- Updates the list of available players after a player has logged off.
END//
DELIMITER ;

-- Challenge a player. Needs both the names of the challenger and the selected opponent.
DELIMITER //
CREATE PROCEDURE ChallengePlayer(IN prChallenger VARCHAR(20), IN prSelectedOpponent VARCHAR(20), OUT prGameID INT)
BEGIN

	INSERT INTO Game() VALUES(); -- Creates a record in game table for the players to use for their match.
	SET @LASTGAMEID = LAST_INSERT_ID(); -- Stores the ID of the game that was just created.
	SET prGameID =  @LASTGAMEID; -- output parameter will be set as the last game ID

	SET @PLAYER1ID = (SELECT PlayerID FROM Player WHERE Player.PlayerName = prChallenger);
	SET @PLAYER2ID = (SELECT PlayerID FROM Player WHERE Player.PlayerName = prSelectedOpponent);

	INSERT INTO PlayerGame(PlayerID, GameID, ChallengeStatus) VALUES(@PLAYER1ID, @LASTGAMEID, 'Accepted');
	INSERT INTO PlayerGame(PlayerID, GameID) VALUES(@PLAYER2ID, @LASTGAMEID);

	UPDATE Player
	SET PlayerStatus = 'Not Available'
	WHERE PlayerName = prChallenger OR PlayerName = prSelectedOpponent;

END//
DELIMITER ;

-- Accept challenge
DELIMITER //
CREATE PROCEDURE AcceptChallenge(IN prGameID INT)
BEGIN
	UPDATE PlayerGame
	SET ChallengeStatus = 'Accepted'
	WHERE GameID = prGameID;
	
	INSERT INTO Board(GameID) VALUES(prGameID);
	SET @LASTBOARDID = LAST_INSERT_ID(); -- Stores the ID of the board that was just created.
	CALL LayOutBoard(@LASTBOARDID); -- after both players are ready for the game, the board that the game will take place on needs to be set up.

END//
DELIMITER ;

-- Decline challenge
DELIMITER //
CREATE PROCEDURE DeclineChallenge(IN prGameID INT)
BEGIN
	SET @PLAYER1ID = (SELECT PlayerID FROM PlayerGame WHERE GameID = prGameID ORDER BY PlayerID DESC LIMIT 1);
	SET @PLAYER2ID = (SELECT PlayerID FROM PlayerGame WHERE GameID = prGameID ORDER BY PlayerID ASC LIMIT 1);

	DELETE FROM PlayerGame -- removes the records in the PlayerGame table where the game ID is the game both the players are assigned to.
	WHERE GameID = prGameID;
	
	DELETE FROM Game  -- deletes the game as it has been declined by the opponent.
	WHERE GameID = prGameID;

	UPDATE Player
	SET PlayerStatus = 'Available' -- Since the challenge was declined, the players need to be added back onto the list of players online.
	WHERE PlayerID = @PLAYER1ID OR PlayerID = @PLAYER2ID; -- Add the players back onto the list of players online as challenge was cancelled.
	CALL ShowOnlineList(); -- we can now see that they have been added back onto the list of available players.
END//
DELIMITER ;

-- Creates sharks according to how many are allowed on the board. We need to add these sharks to the specific board.
DELIMITER //
CREATE PROCEDURE LayOutBoard(IN prBoardID INT)
BEGIN

	SET @MAXIMUMSHARKS = (SELECT MaximumSharks FROM Board WHERE Board.BoardID = prBoardID);
	SET @MAXWIDTH = (SELECT MaxWidth FROM Board WHERE Board.BoardID = prBoardID);
	SET @MAXHEIGHT = (SELECT MaxHeight FROM Board WHERE Board.BoardID = prBoardID);

	SET @COUNTER = 0;

	-- creating sharks
	WHILE @COUNTER < @MAXIMUMSHARKS DO
		INSERT INTO Shark(BoardID, LocationX, LocationY) 
		VALUES(
			prBoardID,
			RandomNumberGenerator(0,@MAXWIDTH), 
			RandomNumberGenerator(0,@MAXHEIGHT)
		);
		SET @COUNTER = (@COUNTER + 1);
	END WHILE;

END//
DELIMITER ;

-- Simulating what happens when a player clicks a shark.
DELIMITER //
CREATE PROCEDURE ClickShark(IN prPlayerID INT, IN prSharkID INT)
BEGIN
	-- the main reason for retrieving the board ID of the shark is to retreive the maximum width of the board for the random number generator to work.
	SET @SHARKSBOARDID = (SELECT BoardID FROM Shark WHERE SharkID = prSharkID);
	SET @MAXWIDTH = (SELECT MaxWidth FROM Board WHERE Board.BoardID = @SHARKSBOARDID);

	UPDATE PlayerGame
	SET Score = Score + 1
	WHERE PlayerID = prPlayerID;

	UPDATE Shark
	SET LocationX = RandomNumberGenerator(0,@MAXWIDTH), 
		LocationY = DEFAULT, 
		Speed = Speed - 1
	WHERE SharkID = prSharkID AND BoardID = @SHARKSBOARDID;
END//
DELIMITER ;

-- This procedure simulates the movement of sharks down the board. Since sharks are only created after a game has been accepted, and the
-- board has been laid out, it is safe to assume that all sharks will need to move. This means that all sharks will be affected.
DELIMITER //
CREATE PROCEDURE MoveSharksTest(IN prTimes INT)
BEGIN
	SET @C = 0;
	SET @SHARKSMOVEDTOTOP = 0;
	WHILE @C < prTimes DO
		SET @SHARKSMOVEDTOTOP = @SHARKSMOVEDTOTOP + (SELECT COUNT(SharkID) FROM Shark WHERE LocationY <= 0);

		UPDATE Shark
		SET LocationY = DEFAULT, LocationX = RandomNumberGenerator(0,100)
		WHERE LocationY <= 0; -- if a shark hits the bottom of a board, it goes back to the top and moves to a random point on the x-axis.

		UPDATE Shark
		SET LocationY = LocationY + Speed; -- All sharks need to move down according to their speed.
		SET @C = @C + 1;

	END WHILE;

	SELECT prTimes AS MovementSteps, @SHARKSMOVEDTOTOP AS SharksMovedToTop;
END//
DELIMITER ;

-- Game Over
DELIMITER //
CREATE PROCEDURE GameOver(IN prGameID INT)
BEGIN
	SET @HIGHESTSCORE = (SELECT Score FROM PlayerGame WHERE GameID = prGameID ORDER BY Score DESC LIMIT 1);
	SET @PLAYER1ID = (SELECT PlayerID FROM PlayerGame WHERE GameID = prGameID ORDER BY PlayerID DESC LIMIT 1);
	SET @PLAYER2ID = (SELECT PlayerID FROM PlayerGame WHERE GameID = prGameID ORDER BY PlayerID ASC LIMIT 1);
	SET @WINNERID = (SELECT PlayerID FROM PlayerGame WHERE GameID = prGameID AND Score = @HIGHESTSCORE LIMIT 1);
	SET @LOSERID = (SELECT PlayerID FROM PlayerGame WHERE GameID = prGameID AND Score != @HIGHESTSCORE LIMIT 1);
	SET @SAMESCORE = (SELECT COUNT(Score) FROM PlayerGame WHERE GameID = prGameID AND Score = @HIGHESTSCORE);
	SET @BOARDID = (SELECT BoardID FROM Board WHERE GameID = prGameID);
	SELECT @SAMESCORE;
	
	IF @SAMESCORE = 2 THEN -- draw
		UPDATE Player
		SET WinningStreak = WinningStreak -- on a draw, both player's winning streaks will be unchanged.
		WHERE PlayerID = @PLAYER1ID OR PlayerID = @PLAYER2ID;
		SELECT 'Draw';
	ELSE
		UPDATE Player
		SET WinningStreak = WinningStreak + 1
		WHERE PlayerID = @WINNERID; -- Add +1 to the winning streak of the winning player

		UPDATE Player
		SET WinningStreak = 0
		WHERE PlayerID = @LOSERID; -- Reset the losing player's winning streak to 0
	END IF;

	UPDATE Player
	SET PlayerStatus = 'Available'
	WHERE PlayerID = @PLAYER1ID OR PlayerID = @PLAYER2ID; -- Add the players back onto the list of players online.

	DELETE FROM Shark
	WHERE BoardID = @BOARDID; -- deletes the sharks involved in the game that just ended.

	CALL ShowOnlineList();
END//
DELIMITER ;

/*
///////////////////////////////////////////////////////////////
-- ///////             Admin Procedures        ///////////////
/////////////////////////////////////////////////////////////
*/

-- administrator viewing players. This only shows information they need to see i.e. name, password, last online and status.
DELIMITER //
CREATE PROCEDURE ViewPlayers()
BEGIN
	SELECT PlayerName AS Name, PlayerPassword AS Password, PlayerStatus AS Status, LastOnline FROM Player; 
END//
DELIMITER ;

-- administrator viewing running games. Only running games are displayed.
DELIMITER //
CREATE PROCEDURE ViewRunningGames()
BEGIN
	SELECT * FROM Game
	WHERE TimeRemaining > 0;
END//
DELIMITER ;

-- administrator deleting a running game. Only running games can be deleted from this procedure.
DELIMITER //
CREATE PROCEDURE KillRunningGame(IN prGameID INT)
BEGIN
	SET @TIMEREMAINING = (SELECT TimeRemaining FROM Game WHERE Game.GameID = prGameID);
	IF @TIMEREMAINING > 0 THEN
		DELETE FROM Game
		WHERE Game.GameID = prGameID;
		SELECT CONCAT('Successfully deleted game ', prGameID) AS KillRunningGame;
	ELSE
		SELECT CONCAT('Cannot delete game ', prGameID, ' as it is not running.') AS KillRunningGame;
	END IF;
	
END//
DELIMITER ;

-- administrator deleting a player based on the player's name.
DELIMITER //
CREATE PROCEDURE DeletePlayer(IN prPlayerName VARCHAR(20))
BEGIN
	IF PlayerExists(prPlayerName) = TRUE THEN
		DELETE FROM Player
		WHERE Player.PlayerName = prPlayerName;
		SELECT CONCAT('Successfully deleted player ', prPlayerName) AS PlayerDeletion;
	ELSE
		SELECT CONCAT('Cannot delete player ', prPlayerName, ' as they are not in our system.') AS PlayerDeletion;
	END IF;
	CALL ViewPlayers();
END//
DELIMITER ;

-- administrator unlocking a player based on the player's name.
DELIMITER //
CREATE PROCEDURE UnlockPlayer(IN prPlayerName VARCHAR(20))
BEGIN
	IF PlayerExists(prPlayerName) = TRUE THEN
		UPDATE Player
		SET PlayerStatus = 'Offline', TriesLeft = 5
		WHERE PlayerName = prPlayerName;
		SELECT CONCAT('Successfully unlocked player ', prPlayerName) AS UnlockPlayer;
	ELSE
		SELECT CONCAT('Cannot unlock player ', prPlayerName, ' as they are not in our system.') AS UnlockPlayer;
	END IF;
	CALL ViewPlayers();
END//
DELIMITER ;

-- administrator changing the password of a player based on the player's name.
DELIMITER //
CREATE PROCEDURE ChangePassword(IN prPlayerName VARCHAR(20), IN prNewPassword VARCHAR(20))
BEGIN
	IF PlayerExists(prPlayerName) = TRUE THEN
		UPDATE Player
		SET PlayerPassword = prNewPassword
		WHERE PlayerName = prPlayerName;
		SELECT CONCAT('Successfully changed password for ', prPlayerName, ' to ', prNewPassword) AS PasswordChanged;
	ELSE
		SELECT CONCAT('Cannot change password for ', prPlayerName, ' as they are not in our system.') AS PasswordChanged;
	END IF;
	CALL ViewPlayers();
END//
DELIMITER ;

-- administrator deleting all games from database.
DELIMITER //
CREATE PROCEDURE DeleteAllGames()
BEGIN
	DELETE FROM Game;
END//
DELIMITER ;

/*
///////////////////////////////////////////////////////////////
-- ///////             Functions               ///////////////
/////////////////////////////////////////////////////////////
*/

-- Function returning either true/false representing whether a player exists.
DELIMITER //
CREATE FUNCTION PlayerExists(prPlayerName VARCHAR(20))
	RETURNS BOOLEAN
BEGIN
	SET @PlayerExists = (SELECT COUNT(PlayerName) FROM Player WHERE PlayerName = prPlayerName);
	RETURN @PlayerExists;
END//
DELIMITER ;


-- Function generating a random number according to the range given. 
DELIMITER //
CREATE FUNCTION RandomNumberGenerator(prRangeLower INT, prRangeUpper INT)
	RETURNS INT
BEGIN
	SET @RANDOMNUMBER = FLOOR(prRangeLower + RAND() *prRangeUpper ); -- Generates a random number according to range given. 
	RETURN @RANDOMNUMBER;
END//
DELIMITER ;

/*
///////////////////////////////////////////////////////////////
-- ///////           Testing procedures        ///////////////
/////////////////////////////////////////////////////////////
*/

DELIMITER //
CREATE PROCEDURE RunTest()
BEGIN

	CALL LoginPlayer('Gittyburg','123456'); -- Inserting players into the player table. The login player procedure will automatically decide whether a player exists or needs to be created.
	CALL LoginPlayer('Ror','123456');
	CALL LoginPlayer('George','123456');
	CALL LoginPlayer('Max','passy1');
	CALL LoginPlayer('Smithy','mypass432');

	-- Simulting a player getting locked by entering their password wrong 5 times.
	CALL LoginPlayer('Smithy','wrongpassy1'); 
	CALL LoginPlayer('Smithy','wrongpassy1'); 
	CALL LoginPlayer('Smithy','wrongpassy1'); 
	CALL LoginPlayer('Smithy','wrongpassy1'); 
	CALL LoginPlayer('Smithy','wrongpassy1');
	CALL LoginPlayer('Smithy','mypass432'); -- even though they entered their password correctly this time, they still can't login as their account is locked.
	SELECT * FROM Player ORDER BY PlayerStatus DESC; -- We can see that the player, in this case Smithy, has had his PlayerStatus changed to locked
	CALL Logoff('Gittyburg'); -- Player loggin off the game thus being removed from the list of available players
	CALL LoginPlayer('Gittyburg', '123456'); -- Player logs back in. At this stage, Gittyburg already exists so the system will check to see if their password is correct.

	CALL ChallengePlayer('Ror', 'George', @GAMEID); -- Challenging a player based on the players shown as available on the list of available players.
	SELECT * FROM PlayerGame; -- We can see that the person being challenged has not accepted their challenge yet. i.e. they are pending.
	CALL AcceptChallenge(@GAMEID); -- Both participants of a game have accepted. The game will now start (i.e. the board will be layed out).
	SELECT * FROM PlayerGame; -- we can see that they have now accepted the challenge.
	CALL ClickShark(3,1); -- Simulating a player clicking a shark. Parameters are PlayerID and SharkID. In this example, the player with PlayerID of 3 gets two points and the player with PlayerID of 2 gets 1 point.
	CALL ClickShark(2,1);
	CALL ClickShark(3,2);

	SELECT * FROM Shark; -- shows the shark's location on the y-axis before the move sharks test procedure is run
	CALL MoveSharksTest(51); -- testing the ability to move sharks down the y-axis. This will move all the sharks in the shark table based on parameter given. The shark's speed multiplies movement.
	SELECT * FROM Shark; -- shows the shark's location on the x and y-axis after the move sharks test procedure is run 


	SELECT * FROM Player;
	SELECT * FROM Game;
	SELECT * FROM PlayerGame;
	SELECT * FROM Board;
	SELECT * FROM Shark;


	CALL GameOver(@GAMEID); -- Ends the game. We need to find who won the game and adjust the player's winning streak accordingly. We can also delete the sharks as the game is finished.
	select * from Board;
	SELECT * FROM Shark; -- Sharks are deleted after a game has finished.

	CALL ChallengePlayer('Max', 'Gittyburg', @GAMEID); -- Another challenge between two players
	CALL DeclineChallenge(@GAMEID); -- If a challenge is declined by the opponent, the players will need to be added back onto the list of available players.

	/*SELECT PlayerGame.PlayerID, Player.PlayerName, PlayerGame.GameID, PlayerGame.ChallengeStatus, PlayerGame.Score FROM PlayerGame
	JOIN Player ON Player.PlayerID = PlayerGame.PlayerID;*/

	-- Admin procedures
	CALL ViewPlayers(); -- Gives the administrator a list of the players in their system. Shows only important attributes.
	CALL LoginPlayer('Steve', 'Lazypass7'); -- Allows the administrator to create a new player record. They follow the same procedure as a player i.e. can only create a player if player name doesnt already exist. 
	CALL ViewRunningGames();
	CALL DeletePlayer('Ror'); -- when a player is deleted, only the player and playergame tables are affected.
	CALL UnlockPlayer('Smithy');
	CALL ChangePassword('Smithy', 'NewPass1');
	CALL KillRunningGame(1); -- deletes the game, and all the data associated with the game. Can only delete running games from this procedure.

	-- We can see that when a game is killed by the admin, the playergame, board and shark entries that are all tied to that game are deleted.
	-- in contrast, when a game naturally ends from the GameOver procedure, only the sharks are deleted. Notice the players are not deleted
	-- when the admin kills the game.
	SELECT * FROM Player;
	SELECT * FROM Game;
	SELECT * FROM PlayerGame;
	SELECT * FROM Board;
	SELECT * FROM Shark;

END//
DELIMITER ;

CALL CreateGameSchema();
-- CALL RunTest(); -- just for the sample data purposes.